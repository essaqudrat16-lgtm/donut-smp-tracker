const express = require("express");
const path = require("path");
require("dotenv").config();

const app = express();
const PORT = process.env.PORT || 3000;
const API_KEY = process.env.DONUT_API_KEY;

// Serve the website files from this project folder.
app.use(express.static(__dirname));

app.get("/api/stats/:username", async (req, res) => {
  let username = String(req.params.username || "").trim();

  if (!/^[.]?[a-zA-Z0-9_]{1,16}$/.test(username)) {
    return res.status(400).json({ error: "Invalid Minecraft username." });
  }

  if (!API_KEY) {
    return res.status(500).json({
      error: "Missing API key. Add DONUT_API_KEY to your .env file."
    });
  }

  try {
    // Confirm this endpoint and authentication format against the current
    // Donut SMP API documentation for the key you were issued.
    const upstream = await fetch(
      "https://api.donutsmp.net/v1/stats/" + encodeURIComponent(username),
      {
        method: "GET",
        headers: {
          Authorization: `Bearer ${API_KEY}`,
          Accept: "application/json"
        },
        signal: AbortSignal.timeout(15000)
      }
    );

    const body = await upstream.json().catch(() => ({}));

    if (!upstream.ok) {
      console.error("Donut API status:", upstream.status, body);
      return res.status(upstream.status).json({
        error:
          upstream.status === 401 || upstream.status === 403
            ? "API key rejected or not authorized. Check the key and API documentation."
            : upstream.status === 404
            ? "The API endpoint or player was not found. Check the API documentation and username."
            : upstream.status === 429
            ? "API rate limit reached. Try again later."
            : "Donut SMP API request failed.",
        upstreamStatus: upstream.status
      });
    }

    const stats = body && (body.result ?? body.data ?? body);
    if (!stats || typeof stats !== "object") {
      return res.status(502).json({ error: "Unexpected response from Donut SMP API." });
    }

    res.json({ username, stats });
  } catch (error) {
    console.error("Stats request error:", error.message);
    res.status(502).json({
      error: "Could not reach the Donut SMP API. Check your internet connection and API endpoint."
    });
  }
});

app.listen(PORT, () => {
  console.log(`Donut Tracker running at http://localhost:${PORT}`);
});
