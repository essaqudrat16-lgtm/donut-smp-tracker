DONUT TRACKER — VS CODE SETUP

FILES
- index.html: the complete website
- server.js: the backend proxy for the Donut SMP API
- package.json: Node.js project settings
- .env.example: template for your private API key
- .gitignore: helps prevent publishing the API key

SETUP
1. Install Node.js LTS from https://nodejs.org/ if you do not already have it.
2. Open this folder in VS Code.
3. Copy .env.example and name the copy .env.
4. Open .env and replace PASTE_YOUR_REAL_API_KEY_HERE with your own API key.
5. In VS Code choose Terminal > New Terminal.
6. Run: npm install
7. Run: npm start
8. Open http://localhost:3000 in your browser.

IMPORTANT API NOTES
- Do not share your API key or publish the .env file.
- The server uses https://api.donutsmp.net/v1/stats/{username} with Bearer authentication.
- API endpoints, authentication rules, rate limits, and response fields can change. If the lookup returns an error, check the current official Donut SMP API documentation and update server.js accordingly.
- A live leaderboard endpoint has not been wired in.
- Ore counts are manually tracked in your browser; they are not read from Minecraft.
- This is an unofficial fan project.
